# Donate for a cause



A web interface where users can donate their goods such as old books , toys and unused medicines to NGOs. People can donate the goods by filling up a form. NGO's can create their account and search for the goods that they are in need of.

![GitHub Logo](/demo.gif)

## Tech stack
Front end | Back end
------------ | -------------
HTML | Php
CSS | MySQL
JavaScript | 

## Key Features
* People can fill a form and donate the goods that they want to donate.
* NGO's can create an account and look for the goods they want.
* Admin can control both NGO and user.

## View the website live
http://ngodonationportal.epizy.com/




## Show your support
Star this repository if you really like it!
Happy Coding!