<?php
    $host = "localhost";
    $user = "root";
    $pass = "";
    $db = "ipfinal";
    $conn = mysqli_connect($host, $user, $pass, $db) or die('Error Connecting');
    

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Form</title>
    <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />

    <link rel="stylesheet" href="user.css"/>


    <style>
        a{
            color: grey;
        }
        a:hover
        {
            color: black;
        
        }
    </style>
</head>
<body>
    
<?php

if(isset($_POST['submitid']))
    {
        $Name=$_POST['Name'];
        $Phone=$_POST['Phone'];
        $Email=$_POST['Email'];
        $Address=$_POST['Address'];
        $Choose=$_POST['Choose'];
        $Goods=$_POST['Goods'];
        $Date=$_POST['Date'];
        
        $query1="INSERT INTO User(Name,Phone,Email,Address,Choose,Goods,Date) VALUES('$Name','$Phone','$Email','$Address','$Choose','$Goods','$Date')";
        $res1=mysqli_query($conn,$query1);
        if($res1){
            echo "Registration Successfull";
        }
        else{
            echo "Not Registered";
        }
        
      
    } 


    ?>
    <div class="container"  data-aos="zoom-in" data-aos-duration="1000">

        <h1 style="color: white">Registration Form</h1>
        
        <form id="donate-form" class="donate-form"
        data-aos-easing="ease-in-out" method="post" action="user.php" >
            
        <label for="text" >Name</label>
            <input type="text" id="name" placeholder="Full name" name="Name"
            required minlength="2" maxlength="100"/>




        
            <label for="text" >Contact</label>
            <input type="tel" id="phone" placeholder="5555555555" name="Phone"
            required pattern="[0-9]{10}" />
        
            <label for="text" >Email</label>
            <input type="email" id="email" placeholder="email@address.com" name="Email"
           not-required/>
        
            <label for="text" >Address</label>
            <textarea type="text" placeholder=" enter location" name="Address"></textarea>
            
            <label for="text" name="Choose" >Choose</label>
            <textarea type="text" placeholder=" Medicine/Book/Cloth " name="Choose"></textarea>
           
            <label for="textarea" >Name of things you want</label>
            <textarea type="text" placeholder=" Name enter things you want " name="Goods"></textarea>
            <label for="text">Date:</label>
            <input type="date" id="Date" name="Date">
            <button type="submit"   name="submitid">Register</button>
            <button type="submit"><a role="button"  href="admininfo2.php" style="font-size:20px;text-decoration:none">Available  </a></button>
            
            
         
    
        </form>
    </div>
    <script src="https://unpkg.com/aos@next/dist/aos.js"></script>
    <script>
      AOS.init();
    </script>
    <script src="userScript.js"></script>
</body>
</html>