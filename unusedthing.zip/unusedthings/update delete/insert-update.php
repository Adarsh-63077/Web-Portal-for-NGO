<?php
if(count($_POST)>0)
{    
include 'db.php';
$BookName = $_POST['BookName'];
$Amount = $_POST['Amount'];
$AuthorName = $_POST['AuthorName'];
$Edision = $_POST['Edision'];
if(empty($_POST['id'])){
$query = "INSERT INTO users (BookName,Amount,AuthorName,Edision)
VALUES ('$BookName','$Amount','$AuthorName','$Edision')";
}else{
$query = "UPDATE users set id='" . $_POST['id'] . "', BookName='" . $_POST['BookName'] . "', Amount='" . $_POST['Amount'] . "', AuthorName='" . $_POST['AuthorName'] . "', Edision='" . $_POST['Edision'] . "' WHERE id='" . $_POST['id'] . "'"; 
}
$res = mysqli_query($dbCon, $query);
if($res) {
echo json_encode($res);
} else {
echo "Error: " . $sql . "" . mysqli_error($dbCon);
}
}
?>