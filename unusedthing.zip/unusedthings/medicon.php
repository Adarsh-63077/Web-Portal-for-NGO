<?php
    $server = "localhost";
    $user = "root";
    $password = "";
    $db = "ipfinal";
    $con = mysqli_connect($server, $user, $password, $db) ;
    

?>